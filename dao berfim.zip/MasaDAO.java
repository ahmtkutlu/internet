/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Masa;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class MasaDAO {
    private Masa masa=null;
    private ArrayList<Masa> masalist=null;
    
    public Masa getMasa(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from masa where idMasa="+id);
            rs.next();
            this.masa =new Masa(rs.getInt("idMasa"),rs.getInt("Kapasite"),rs.getString("Durum"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.masa;
    }
     public ArrayList<Masa> list(){
         this.masalist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from masa");
           while(rs.next()) {
               this.masalist.add(new Masa(rs.getInt("idMasa"),rs.getInt("Kapasite"),rs.getString("Durum")));     
           }
            this.masa =new Masa(rs.getInt("idMasa"),rs.getInt("Kapasite"),rs.getString("Durum"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.masalist;
    }
      
       public void delete(int idMasa){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from masa where idMasa="+idMasa);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Masa m){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update masa set Kapasite='"+m.getKapasite()+"',Durum='"+m.getDurum()+"' where idMasa="+m.getIdMasa());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Masa m){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into masa(Kapasite,Durum) values ('"+m.getKapasite()+"','"+m.getDurum()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        
      
        }
        
       
        
    }
    
    

