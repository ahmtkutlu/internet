/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Personel;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class PersonelDAO {
    private Personel personel=null;
    private ArrayList<Personel> personellist=null;
    
    public Personel getPersonel(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from personel where idPersonel="+id);
            rs.next();
            this.personel =new Personel(rs.getInt("idPersonel"),rs.getString("Ad"),rs.getString("Soyad"),rs.getString("Parola"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.personel;
    }
     public ArrayList<Personel> list(){
         this.personellist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from personel");
           while(rs.next()) {
               this.personellist.add(new Personel(rs.getInt("idPersonel"),rs.getString("Ad"),rs.getString("Soyad"),rs.getString("Parola")));     
           }
            this.personel =new Personel(rs.getInt("idPersonel"),rs.getString("Ad"),rs.getString("Soyad"),rs.getString("Parola"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.personellist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from personel where idPersonel="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Personel p){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update personel set Ad='"+p.getAd()+"',Soyad='"+p.getSoyad()+"',Parola='"+p.getParola()+"' where idPersonel="+p.getIdPersonel());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Personel p){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into personel(Ad,Soyad,Parola) values ('"+p.getAd()+"','"+p.getSoyad()+"','"+p.getParola()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        
      
        }
        
       
        
    }
    
    

