/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.OdemeTur;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class OdemeTurDAO {
    private OdemeTur odemetur=null;
    private ArrayList<OdemeTur> odemeturlist=null;
    
    public OdemeTur getOdemeTur(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from odemetur where idOdemeTur="+id);
            rs.next();
            this.odemetur =new OdemeTur(rs.getInt("idOdemeTur"),rs.getString("OdemeTur"),rs.getString("Aciklama"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.odemetur;
    }
     public ArrayList<OdemeTur> list(){
         this.odemeturlist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from odemetur");
           while(rs.next()) {
               this.odemeturlist.add(new OdemeTur(rs.getInt("idOdemeTur"),rs.getString("OdemeTur"),rs.getString("Aciklama")));     
           }
            this.odemetur =new OdemeTur(rs.getInt("idOdemeTur"),rs.getString("OdemeTur"),rs.getString("Aciklama"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.odemeturlist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from odemetur where idOdemeTur="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(OdemeTur o){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update odemetur set OdemeTur='"+o.getOdemeTur()+"',Aciklama='"+o.getAciklama()+"' where idOdemeTur="+o.getOdemeTur());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(OdemeTur o){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into odemetur(OdemeTur,Aciklama) values ('"+o.getOdemeTur()+"','"+o.getAciklama()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        
       
        
    }
    
    

