/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Musteri;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class MusteriDAO {
    private Musteri musteri=null;
    private ArrayList<Musteri> musterilist=null;
    
    public Musteri getMusteri(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from musteri where idMusteri="+id);
            rs.next();
            this.musteri =new Musteri(rs.getInt("idMusteri"),rs.getString("MusteriAd"),rs.getString("MusteriSoyad"),rs.getString("Email"),rs.getString("Adres"),rs.getString("Telefon"),rs.getDate("IlkSiparis"),rs.getInt("SiparisSayisi"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.musteri;
    }
     public ArrayList<Musteri> list(){
         this.musterilist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from musteri");
           while(rs.next()) {
               this.musterilist.add(new Musteri(rs.getInt("idMusteri"),rs.getString("MusteriAd"),rs.getString("MusteriSoyad"),rs.getString("Email"),rs.getString("Adres"),rs.getString("Telefon"),rs.getDate("IlkSiparis"),rs.getInt("SiparisSayisi")));     
           }
            this.musteri =new Musteri(rs.getInt("idMusteri"),rs.getString("MusteriAd"),rs.getString("MusteriSoyad"),rs.getString("Email"),rs.getString("Adres"),rs.getString("Telefon"),rs.getDate("IlkSiparis"),rs.getInt("SiparisSayisi"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.musterilist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from musteri where idMusteri="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Musteri ms){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update musteri set MusteriAd='"+ms.getMusteriAd()+"',MusteriSoyad='"+ms.getMusteriSoyad()+"',Email='"+ms.getEmail()+"',Adres='"+ms.getAdres()+"',Telefon='"+ms.getTelefon()+"',IlkSiparis='"+ms.getIlkSiparis()+"',SiparisSayisi='"+ms.getSiparisSayisi()+"' where idMusteri="+ms.getIdMusteri());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }



        public void create(Musteri ms){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into musteri(MusteriAd,MusteriSoyad,Email,Adres,Telefon,IlkSiparis,SiparisSayisi) values ('"+ms.getMusteriAd()+"','"+ms.getMusteriSoyad()+"','"+ms.getEmail()+"','"+ms.getTelefon()+"','"+ms.getIlkSiparis()+"','"+ms.getSiparisSayisi()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        
       
        
    }
    
    

