/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Rezervasyon;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class RezervasyonDAO {
    private Rezervasyon rezervasyon=null;
    private ArrayList<Rezervasyon> rezervasyonlist=null;
    
    public Rezervasyon getRezervasyon(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from rezervasyon where idRezervasyon="+id);
            rs.next();
            this.rezervasyon =new Rezervasyon(rs.getInt("idRezervasyon"),rs.getString("Ad"),rs.getString("Soyad"),rs.getInt("Telefon"),rs.getInt("KisiSayisi"),rs.getString("Tarih"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.rezervasyon;
    }
     public ArrayList<Rezervasyon> list(){
         this.rezervasyonlist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from rezervasyon");
           while(rs.next()) {
               this.rezervasyonlist.add(new Rezervasyon(rs.getInt("idRezervasyon"),rs.getString("Ad"),rs.getString("Soyad"),rs.getInt("Telefon"),rs.getInt("KisiSayisi"),rs.getString("Tarih")));     
           }
            this.rezervasyon =new Rezervasyon(rs.getInt("idRezervasyon"),rs.getString("Ad"),rs.getString("Soyad"),rs.getInt("Telefon"),rs.getInt("KisiSayisi"),rs.getString("Tarih"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.rezervasyonlist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from rezervasyon where idRezervasyon="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Rezervasyon r){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update rezervasyon set Ad='"+r.getAd()+"',Soyad='"+r.getSoyad()+"',Telefon='"+r.getTelefon()+"',KisiSayisi='"+r.getKisiSayisi()+"',Tarih='"+r.getTarih()+"' where idRezervasyon="+r.getIdRezervasyon());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Rezervasyon r){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into rezervasyon(Kapasite,Durum) values ('"+r.getAd()+"','"+r.getSoyad()+"','"+r.getTelefon()+"','"+r.getKisiSayisi()+"','"+r.getTarih()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        
      
        }
        
       
        
    }
    
    

