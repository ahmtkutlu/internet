/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Kayit;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class KayitDAO {
    private Kayit kayit=null;
    private ArrayList<Kayit> kayitlist=null;
    
    public Kayit getKayit(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from kayit where idKayit="+id);
            rs.next();
            this.kayit =new Kayit(rs.getInt("idKayit"),rs.getString("Ad"),rs.getString("Soyad"),rs.getInt("Telefon"),rs.getInt("KisiSayisi"),rs.getString("Tarih"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.kayit;
    }
     public ArrayList<Kayit> list(){
         this.kayitlist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from kayit");
           while(rs.next()) {
               this.kayitlist.add(new Kayit(rs.getInt("idKayit"),rs.getString("Ad"),rs.getString("Soyad"),rs.getInt("Telefon"),rs.getInt("KisiSayisi"),rs.getString("Tarih")));     
           }
            this.kayit =new Kayit(rs.getInt("idKayit"),rs.getString("Ad"),rs.getString("Soyad"),rs.getInt("Telefon"),rs.getInt("KisiSayisi"),rs.getString("Tarih"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.kayitlist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from kayit where idKayit="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Kayit k){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update kayit set Ad='"+k.getAd()+"',Soyad='"+k.getSoyad()+"' ,Telefon='"+k.getTelefon()+"',KisiSayisi='"+k.getKisiSayisi()+"',Tarih='"+k.getTarih()+"' where idKayit="+k.getIdkayit());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Kayit k){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into kayit(Ad,Soyad,Telefon,KisiSayisi,Tarih) values ('"+k.getAd()+"','"+k.getSoyad()+"','"+k.getTelefon()+"','"+k.getKisiSayisi()+"','"+k.getTarih()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        
       
        
    }
    
    

