/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Adisyon;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class AdisyonDAO {
    private Adisyon adisyon=null;
    private ArrayList<Adisyon> adisyonlist=null;
    
    public Adisyon getAdisyon(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from adisyon where idAdisyon="+id);
            rs.next();
            this.adisyon =new Adisyon(rs.getInt("idAdisyon"),rs.getInt("MasaNo"),rs.getInt("Tutar"),rs.getString("Tarih"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.adisyon;
    }
     public ArrayList<Adisyon> list(){
         this.adisyonlist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from adisyon");
           while(rs.next()) {
               this.adisyonlist.add(new Adisyon(rs.getInt("idAdisyon"),rs.getInt("MasaNo"),rs.getInt("Tutar"),rs.getString("Tarih")));     
           }
            this.adisyon =new Adisyon(rs.getInt("idAdisyon"),rs.getInt("MasaNo"),rs.getInt("Tutar"),rs.getString("Tarih"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.adisyonlist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from adisyon where idAdisyon="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Adisyon a){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update adisyon set Tarih='"+a.getTarih()+"',Tutar='"+a.getTutar()+"' ,MasaNo='"+a.getMasaNo()+"' where idAdisyon="+a.getIdAdisyon());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Adisyon a){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into adisyon(Tarih,Tutar,MasaNo) values ('"+a.getTarih()+"','"+a.getMasaNo()+"','"+a.getTutar()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        
       
        
    }
    
    

