/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.PersonelGorev;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class PersonelGorevDAO {
    private PersonelGorev personelgorev=null;
    private ArrayList<PersonelGorev> personelgorevlist=null;
    
    public PersonelGorev getPersonelGorev(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from personelgorev where idPersonelGorev="+id);
            rs.next();
            this.personelgorev =new PersonelGorev(rs.getInt("idPersonelGorev"),rs.getString("Gorev"),rs.getString("Aciklama"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.personelgorev;
    }
     public ArrayList<PersonelGorev> list(){
         this.personelgorevlist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from personelgorev");
           while(rs.next()) {
               this.personelgorevlist.add(new PersonelGorev(rs.getInt("idPersonelGorev"),rs.getString("Gorev"),rs.getString("Aciklama")));     
           }
            this.personelgorev =new PersonelGorev(rs.getInt("idPersonelGorev"),rs.getString("Gorev"),rs.getString("Aciklama"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.personelgorevlist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from personelgorev where idPersonelGorev="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(PersonelGorev pg){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update personelgorev set Gorev='"+pg.getGorev()+"',Aciklama='"+pg.getAciklama()+"' where idPersonelGorev="+pg.getIdPersonelGorev());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(PersonelGorev pg){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into personelgorev(Gorev,Aciklama) values ('"+pg.getGorev()+"','"+pg.getAciklama()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        
       
        
    }
    
    

