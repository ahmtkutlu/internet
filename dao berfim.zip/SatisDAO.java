/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Satis;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class SatisDAO {
    private Satis satis=null;
    private ArrayList<Satis> satislist=null;
    
    public Satis getSatis(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from satis where idSatis="+id);
            rs.next();
            this.satis =new Satis(rs.getInt("idSatis"),rs.getInt("idAdisyon"),rs.getInt("idUrun"),rs.getInt("idMasa"),rs.getInt("Adet"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.satis;
    }
     public ArrayList<Satis> list(){
         this.satislist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from satis");
           while(rs.next()) {
               this.satislist.add(new Satis(rs.getInt("idSatis"),rs.getInt("idAdisyon"),rs.getInt("idUrun"),rs.getInt("idMasa"),rs.getInt("Adet")));     
           }
            this.satis =new Satis(rs.getInt("idSatis"),rs.getInt("idAdisyon"),rs.getInt("idUrun"),rs.getInt("idMasa"),rs.getInt("Adet"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.satislist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from satis where idSatis="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Satis s){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update satis set Adet='"+s.getAdet()+"' where idSatis="+s.getIdSatis());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Satis s){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into satis(Adet) values ('"+s.getAdet()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        
       
        
    }
    
    

