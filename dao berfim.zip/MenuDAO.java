/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Menu;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
public class MenuDAO {
  private Menu menu=null;
    private ArrayList<Menu> menulist=null;
    
    public Menu getMenu(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from menu where idMenu="+id);
            rs.next();
            this.menu =new Menu(rs.getInt("idMenu"),rs.getString("YemekAd"),rs.getInt("Fiyat"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.menu;
    }
     public ArrayList<Menu> list(){
         this.menulist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from menu");
           while(rs.next()) {
               this.menulist.add(new Menu(rs.getInt("idMenu"),rs.getString("YemekAd"),rs.getInt("Fiyat")));     
           }
            this.menu =new Menu(rs.getInt("idMenu"),rs.getString("YemekAd"),rs.getInt("Fiyat"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.menulist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from menu where idMenu="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Menu me){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update menu set YemekAd='"+me.getYemekAd()+"',Fiyat='"+me.getFiyat()+"' where idMenu="+me.getIdMenu());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Menu me){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into menu(YemekAd,Fiyat) values ('"+me.getYemekAd()+"','"+me.getFiyat()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        
      
        }
        
       
        
    }
