/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Urun;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class UrunDAO {
    private Urun urun=null;
    private ArrayList<Urun> urunlist=null;
    
    public Urun getUrun(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from urun where idUrun="+id);
            rs.next();
            this.urun =new Urun(rs.getInt("idUrun"),rs.getInt("idKategori"),rs.getString("UrunAdi"),rs.getString("Aciklama"),rs.getFloat("UrunFiyat"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.urun;
    }
     public ArrayList<Urun> list(){
         this.urunlist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from urun");
           while(rs.next()) {
               this.urunlist.add(new Urun(rs.getInt("idUrun"),rs.getInt("idKategori"),rs.getString("UrunAdi"),rs.getString("Aciklama"),rs.getFloat("UrunFiyat")));     
           }
            this.urun =new Urun(rs.getInt("idUrun"),rs.getInt("idKategori"),rs.getString("UrunAdi"),rs.getString("Aciklama"),rs.getFloat("UrunFiyat"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.urunlist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from urun where idUrun="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Urun u){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update urun set UrunAdi='"+u.getUrunAdi()+"',Aciklama='"+u.getAciklama()+"',UrunFiyat='"+u.getUrunFiyat()+"' where idUrun="+u.getIdUrun());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Urun u){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into urun(UrunAdi,Aciklama,UrunFiyat) values ('"+u.getUrunAdi()+"','"+u.getAciklama()+"','"+u.getUrunFiyat()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        
       
        
    }
    
    

