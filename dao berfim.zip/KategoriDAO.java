/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Entitiy.Kategori;
import Utilitiy.ConnectionManager;
import java.util.ArrayList;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author BURCU
 */
public class KategoriDAO {
    private Kategori kategori=null;
    private ArrayList<Kategori> kategorilist=null;
    
    public Kategori getKategori(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from kategori where idKategori="+id);
            rs.next();
            this.kategori =new Kategori(rs.getInt("idKategori"),rs.getString("KategoriAdi"),rs.getString("Aciklama"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.kategori;
    }
     public ArrayList<Kategori> list(){
         this.kategorilist=new ArrayList();
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            ResultSet rs =st.executeQuery("select * from kategori");
           while(rs.next()) {
               this.kategorilist.add(new Kategori(rs.getInt("idKategori"),rs.getString("KategoriAdi"),rs.getString("Aciklama")));     
           }
            this.kategori =new Kategori(rs.getInt("idKategori"),rs.getString("KategoriAdi"),rs.getString("Aciklama"));
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        return this.kategorilist;
    }
      
       public void delete(int id){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("delete from kategori where idKategori="+id);
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());}
    }
        public void update(Kategori k){
        Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            st.executeUpdate("update kategori set KategoriAdi='"+k.getKategoriAdi()+"',Aciklama='"+k.getAciklama()+"' where idKategori="+k.getIdKategori());
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        public void create(Kategori k){
              Connection con =ConnectionManager.getConnection();
        try{
            Statement st =con.createStatement();
            
            st.executeUpdate("insert into kategori(KategoriAdi,Aciklama) values ('"+k.getKategoriAdi()+"','"+k.getAciklama()+"')");
            System.out.println("deneme");
        }
        catch(SQLException ex){
            System.out.println(ex.getMessage());
            
        }
        }
        
       
        
    }
    
    

