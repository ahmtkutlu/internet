/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.SatisDAO;
import Entitiy.Satis;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="satis")
@SessionScoped
public class SatisController {
    private Satis s =null;
    private ArrayList<Satis> slist =null;
    private  SatisDAO sDAO=null;

    public Satis getS() {
        if(this.s==null)
            this.s =new Satis();
        return s;
    }

    public void setS(Satis s) {
        this.s = s;
    }

    public ArrayList<Satis> getlist() {
        if(this.slist==null){
            this.slist=new ArrayList();
            slist=this.getsDAO().list();
                    }
        return this.slist;
    }

    public void setlist(ArrayList<Satis> list) {
        this.slist = list;
    }

    public SatisDAO getsDAO() {
        if(this.sDAO==null)
            this.sDAO = new SatisDAO();
        return sDAO;
    }

    public void setsDAO(SatisDAO sDAO) {
        this.sDAO = sDAO;
    }
    public String delete(int id) {
        this.getsDAO().delete(id);
        this.slist = this.getsDAO().list();
        return "/pages/adminstation/seferler/list";
    }

    public Satis getSatisById(int id) {
        return this.getsDAO().getSatis(id);
    }
    
    

    public String update(int id){
        this.getsDAO().update(this.s);
        this.slist = this.getsDAO().list();
        return "/pages/adminstation/seferler/list";
    }
    
    public String create() {
        this.getsDAO().create(this.s);
        this.slist = this.getsDAO().list();
        this.s=null;
        return "/tamam";
    }
    
    
    
}
