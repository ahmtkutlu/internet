/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.PersonelGorevDAO;
import Entitiy.PersonelGorev;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="personelgorev")
@SessionScoped
public class PersonelGorevController {
    private PersonelGorev pg =null;
    private ArrayList<PersonelGorev> pglist =null;
    private  PersonelGorevDAO pgDAO=null;

    public PersonelGorev getPG() {
        if(this.pg==null)
            this.pg =new PersonelGorev();
        return pg;
    }

    public void setPG(PersonelGorev pg) {
        this.pg = pg;
    }

    public ArrayList<PersonelGorev> getlist() {
        if(this.pglist==null){
            this.pglist=new ArrayList();
            pglist=this.getpgDAO().list();
                    }
        return this.pglist;
    }

    public void setlist(ArrayList<PersonelGorev> list) {
        this.pglist = list;
    }

    public PersonelGorevDAO getpgDAO() {
        if(this.pgDAO==null)
            this.pgDAO = new PersonelGorevDAO();
        return pgDAO;
    }

    public void setpgDAO(PersonelGorevDAO pgDAO) {
        this.pgDAO = pgDAO;
    }
    public String delete(int id) {
        this.getpgDAO().delete(id);
        this.pglist = this.getpgDAO().list();
        return "/pages/adminstation/seferler/list";
    }

    public PersonelGorev getPersonelGorevById(int id) {
        return this.getpgDAO().getPersonelGorev(id);
    }
    
    

    public String update(int id){
        this.getpgDAO().update(this.pg);
        this.pglist = this.getpgDAO().list();
        return "/pages/adminstation/seferler/list";
    }
    
    public String create() {
        this.getpgDAO().create(this.pg);
        this.pglist = this.getpgDAO().list();
        this.pg=null;
        return "/tamam";
    }
    
    
    
}
