/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.KategoriDAO;
import Entitiy.Kategori;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="kategori")
@SessionScoped
public class KategoriController {
    private Kategori k =null;
    private ArrayList<Kategori> klist =null;
    private  KategoriDAO kDAO=null;

    public Kategori getK() {
        if(this.k==null)
            this.k =new Kategori();
        return k;
    }



    public void setK(Kategori k) {
        this.k = k;
    }


    public ArrayList<Kategori> getlist() {
        if(this.klist==null){
            this.klist=new ArrayList();
            klist=this.getkDAO().list();
                    }
        return this.klist;
    }



    public void setlist(ArrayList<Kategori> list) {
        this.klist = list;
    }



    public KategoriDAO getkDAO() {
        if(this.kDAO==null)
            this.kDAO = new KategoriDAO();
        return kDAO;
    }



    public void setkDAO(KategoriDAO kDAO) {
        this.kDAO = kDAO;
    }



    public String delete(int id) {
        this.getkDAO().delete(id);
        this.klist = this.getkDAO().list();
        return "/pages/adminstation/seferler/list";
    }



    public Kategori getKategoriById(int id) {
        return this.getkDAO().getKategori(id);
    }
    
    

    public String update(int id){
        this.getkDAO().update(this.k);
        this.klist = this.getkDAO().list();
        return "/pages/adminstation/seferler/list";
    }
    
    public String create() {
        this.getkDAO().create(this.k);
        this.klist = this.getkDAO().list();
        this.k=null;
        return "/tamam";
    }
    
    
    
}
