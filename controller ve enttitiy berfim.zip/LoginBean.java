/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

import java.io.Serializable;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author Ailem
 */
@ManagedBean
@SessionScoped
public class LoginBean implements Serializable {

    // Basit kullan�c� veritaban� :)
    private static final String[] users = {"Burcu:brc"};

    private String username;
    private String password;

    public boolean loggedIn = false;

    
    public String doLogin() {
        // Her kullan�c�y� �rnek veritaban�m�zdan al :)
        for (String user : users) {
            String dbUsername = user.split(":")[0];
            String dbPassword = user.split(":")[1];

            // Successful login
            if (dbUsername.equals(username) && dbPassword.equals(password)) {
                loggedIn = true;
            }
        }
        return "/pages/adminstation/index2?faces-redirect=true";
    }

    
    public String doLogout() {
        // Kullan�c�n�n oturum a�t���n� g�steren parametreyi yanl�� olarak ayarlay�n.
        loggedIn = false;
        this.username = "";
        this.password = "";
        // Set logout message

        return "/index?faces-redirect=true";
    }

    // ------------------------------
    // Getters & Setters 
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isLoggedIn() {
        return loggedIn;
    }

    public void setLoggedIn(boolean loggedIn) {
        this.loggedIn = loggedIn;
    }
}
