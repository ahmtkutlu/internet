/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.MusteriDAO;
import Entitiy.Musteri;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="musteri")
@SessionScoped
public class MusteriController {
    private Musteri ms =null;
    private ArrayList<Musteri> mslist =null;
    private  MusteriDAO msDAO=null;

    public Musteri getMS() {
        if(this.ms==null)
            this.ms =new Musteri();
        return ms;
    }

    public void setMS(Musteri ms) {
        this.ms = ms;
    }

    public ArrayList<Musteri> getlist() {
        if(this.mslist==null){
            this.mslist=new ArrayList();
            mslist=this.getmsDAO().list();
                    }
        return this.mslist;
    }

    public void setlist(ArrayList<Musteri> list) {
        this.mslist = list;
    }

    public MusteriDAO getmsDAO() {
        if(this.msDAO==null)
            this.msDAO = new MusteriDAO();
        return msDAO;
    }

    public void setmsDAO(MusteriDAO msDAO) {
        this.msDAO = msDAO;
    }
    public String delete(int id) {
        this.getmsDAO().delete(id);
        this.mslist = this.getmsDAO().list();
        return "/pages/adminstation/seferler/list";
    }

    public Musteri getMusteriById(int id) {
        return this.getmsDAO().getMusteri(id);
    }
    
    

    public String update(int id){
        this.getmsDAO().update(this.ms);
        this.mslist = this.getmsDAO().list();
        return "/pages/adminstation/seferler/list";
    }
    
    public String create() {
        this.getmsDAO().create(this.ms);
        this.mslist = this.getmsDAO().list();
        this.ms=null;
        return "/tamam";
    }
    
    
    
}
