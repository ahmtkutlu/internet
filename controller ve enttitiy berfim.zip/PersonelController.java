/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.PersonelDAO;
import Entitiy.Personel;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="personel")
@SessionScoped
public class PersonelController {
    private Personel p =null;
    private ArrayList<Personel> plist =null;
    private  PersonelDAO pDAO=null;

    public Personel getP() {
        if(this.p==null)
            this.p =new Personel();
        return p;
    }

    public void setP(Personel p) {
        this.p = p;
    }

    public ArrayList<Personel> getlist() {
        if(this.plist==null){
            this.plist=new ArrayList();
            plist=this.getpDAO().list();
                    }
        return this.plist;
    }

    public void setlist(ArrayList<Personel> list) {
        this.plist = list;
    }

    public PersonelDAO getpDAO() {
        if(this.pDAO==null)
            this.pDAO = new PersonelDAO();
        return pDAO;
    }

    public void setpDAO(PersonelDAO pDAO) {
        this.pDAO = pDAO;
    }
    public String delete(int id) {
        this.getpDAO().delete(id);
        this.plist = this.getpDAO().list();
        return "/pages/adminstation/personel/list";
    }

    public Personel getPersonelById(int id) {
        return this.getpDAO().getPersonel(id);
    }
    
    public String update(int id){
        this.p=this.getPersonelById(id);
        return "/pages/adminstation/Personel/update";
    }

    public String updatePersonel(int id){
        this.getpDAO().update(this.p);
        this.plist = this.getpDAO().list();
        return "/pages/adminstation/Personel/list";
    }
    
    public String createPersonel() {
        this.getpDAO().create(this.p);
        this.plist = this.getpDAO().list();
        this.p=null;
        return "/pages/adminstation/Personel/list";
    }
    
    
    
}
