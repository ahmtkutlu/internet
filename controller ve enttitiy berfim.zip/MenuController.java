/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.MenuDAO;
import Entitiy.Menu;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="menu")
@SessionScoped
public class MenuController {
    private Menu me =null;
    private ArrayList<Menu> melist =null;
    private  MenuDAO meDAO=null;

    public Menu getME() {
        if(this.me==null)
            this.me =new Menu();
        return me;
    }

    public void setME(Menu me) {
        this.me = me;
    }

    public ArrayList<Menu> getlist() {
        if(this.melist==null){
            this.melist=new ArrayList();
            melist=this.getmeDAO().list();
                    }
        return this.melist;
    }

    public void setlist(ArrayList<Menu> list) {
        this.melist = list;
    }

    public MenuDAO getmeDAO() {
        if(this.meDAO==null)
            this.meDAO = new MenuDAO();
        return meDAO;
    }

    public void setmeDAO(MenuDAO meDAO) {
        this.meDAO = meDAO;
    }
    public String delete(int id) {
        this.getmeDAO().delete(id);
        this.melist = this.getmeDAO().list();
        return "/pages/adminstation/menu/list";
    }

    public Menu getMenuById(int id) {
        return this.getmeDAO().getMenu(id);
    }
    
    public String update(int id){
        this.me=this.getMenuById(id);
        return "/pages/adminstation/Menu/update";
    }

    public String updateMenu(int id){
        this.getmeDAO().update(this.me);
        this.melist = this.getmeDAO().list();
        return "/pages/adminstation/Menu/list";
    }
    
    public String createMenu() {
        this.getmeDAO().create(this.me);
        this.melist = this.getmeDAO().list();
        this.me=null;
        return "/pages/adminstation/Menu/list";
    }
    
    
    
}
