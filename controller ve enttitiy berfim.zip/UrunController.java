/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.UrunDAO;
import Entitiy.Urun;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="urun")
@SessionScoped
public class UrunController {
    private Urun u =null;
    private ArrayList<Urun> ulist =null;
    private  UrunDAO uDAO=null;

    public Urun getU() {
        if(this.u==null)
            this.u =new Urun();
        return u;
    }

    public void setU(Urun u) {
        this.u = u;
    }

    public ArrayList<Urun> getlist() {
        if(this.ulist==null){
            this.ulist=new ArrayList();
            ulist=this.getuDAO().list();
                    }
        return this.ulist;
    }

    public void setlist(ArrayList<Urun> list) {
        this.ulist = list;
    }

    public UrunDAO getuDAO() {
        if(this.uDAO==null)
            this.uDAO = new UrunDAO();
        return uDAO;
    }

    public void setuDAO(UrunDAO uDAO) {
        this.uDAO = uDAO;
    }
    public String delete(int id) {
        this.getuDAO().delete(id);
        this.ulist = this.getuDAO().list();
        return "/pages/adminstation/seferler/list";
    }

    public Urun getUrunById(int id) {
        return this.getuDAO().getUrun(id);
    }
    
    

    public String update(int id){
        this.getuDAO().update(this.u);
        this.ulist = this.getuDAO().list();
        return "/pages/adminstation/seferler/list";
    }
    
    public String create() {
        this.getuDAO().create(this.u);
        this.ulist = this.getuDAO().list();
        this.u=null;
        return "/tamam";
    }
    
    
    
}
