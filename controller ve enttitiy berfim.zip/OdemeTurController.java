/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.OdemeTurDAO;
import Entitiy.OdemeTur;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="odemetur")
@SessionScoped
public class OdemeTurController {
    private OdemeTur o =null;
    private ArrayList<OdemeTur> olist =null;
    private  OdemeTurDAO oDAO=null;

    public OdemeTur getO() {
        if(this.o==null)
            this.o =new OdemeTur();
        return o;
    }

    public void setO(OdemeTur o) {
        this.o = o;
    }

    public ArrayList<OdemeTur> getlist() {
        if(this.olist==null){
            this.olist=new ArrayList();
            olist=this.getoDAO().list();
                    }
        return this.olist;
    }

    public void setlist(ArrayList<OdemeTur> list) {
        this.olist = list;
    }

    public OdemeTurDAO getoDAO() {
        if(this.oDAO==null)
            this.oDAO = new OdemeTurDAO();
        return oDAO;
    }

    public void setoDAO(OdemeTurDAO oDAO) {
        this.oDAO = oDAO;
    }
    public String delete(int id) {
        this.getoDAO().delete(id);
        this.olist = this.getoDAO().list();
        return "/pages/adminstation/seferler/list";
    }

    public OdemeTur getOdemeTurById(int id) {
        return this.getoDAO().getOdemeTur(id);
    }
    
    

    public String update(int id){
        this.getoDAO().update(this.o);
        this.olist = this.getoDAO().list();
        return "/pages/adminstation/seferler/list";
    }
    
    public String create() {
        this.getoDAO().create(this.o);
        this.olist = this.getoDAO().list();
        this.o=null;
        return "/tamam";
    }
    
    
    
}
