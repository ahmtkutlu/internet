/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.KayitDAO;
import Entitiy.Kayit;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="kayit")
@SessionScoped
public class KayitController {
    private Kayit k =null;
    private ArrayList<Kayit> klist =null;
    private  KayitDAO kDAO=null;

    public Kayit getK() {
        if(this.k==null)
            this.k =new Kayit();
        return k;
    }

    public void setK(Kayit k) {
        this.k = k;
    }

    public ArrayList<Kayit> getlist() {
        if(this.klist==null){
            this.klist=new ArrayList();
            klist=this.getkDAO().list();
                    }
        return this.klist;
    }

    public void setlist(ArrayList<Kayit> list) {
        this.klist = list;
    }

    public KayitDAO getkDAO() {
        if(this.kDAO==null)
            this.kDAO = new KayitDAO();
        return kDAO;
    }

    public void setkDAO(KayitDAO kDAO) {
        this.kDAO = kDAO;
    }
    public String delete(int id) {
        this.getkDAO().delete(id);
        this.klist = this.getkDAO().list();
        return "/pages/adminstation/kayit/list";
    }

    public Kayit getKayitById(int id) {
        return this.getkDAO().getKayit(id);
    }
    
    public String update(int id){
        this.k=this.getKayitById(id);
        return "/pages/adminstation/Kayit/update";
    }

    public String updateKayit(int id){
        this.getkDAO().update(this.k);
        this.klist = this.getkDAO().list();
        return "/pages/adminstation/Kayit/list";
    }
    
    public String createKayit() {
        this.getkDAO().create(this.k);
        this.klist = this.getkDAO().list();
        this.k=null;
        return "/pages/adminstation/Kayit/list";
    }
    
    
    
}
