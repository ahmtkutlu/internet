/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.MasaDAO;
import Entitiy.Masa;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="masa")
@SessionScoped
public class MasaController {
    private Masa m =null;
    private ArrayList<Masa> mlist =null;
    private  MasaDAO mDAO=null;

    public Masa getM() {
        if(this.m==null)
            this.m =new Masa();
        return m;
    }

    public void setM(Masa m) {
        this.m = m;
    }

    public ArrayList<Masa> getlist() {
        if(this.mlist==null){
            this.mlist=new ArrayList();
            mlist=this.getmDAO().list();
                    }
        return this.mlist;
    }

    public void setlist(ArrayList<Masa> list) {
        this.mlist = list;
    }

    public MasaDAO getmDAO() {
        if(this.mDAO==null)
            this.mDAO = new MasaDAO();
        return mDAO;
    }

    public void setmDAO(MasaDAO mDAO) {
        this.mDAO = mDAO;
    }
    public String delete(int idMasa){
        this.m=this.getMasaById(idMasa);
        return "/pages/adminstation/menuler/update";
    }
    public String deleteMasa(int idMasa) {
        this.getmDAO().delete(idMasa);
        this.mlist = this.getmDAO().list();
        return "/pages/adminstation/masa/list";
    }

    public Masa getMasaById(int id) {
        return this.getmDAO().getMasa(id);
    }
    
    public String update(int id){
        this.m=this.getMasaById(id);
        return "/pages/adminstation/Masa/update";
    }

    public String updateMasa(int id){
        this.getmDAO().update(this.m);
        this.mlist = this.getmDAO().list();
        return "/pages/adminstation/Masa/list";
    }
    
    public String createMasa() {
        this.getmDAO().create(this.m);
        this.mlist = this.getmDAO().list();
        this.m=null;
        return "/pages/adminstation/Masa/list";
    }
    
    
    
}
