/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ControllerLogin implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        // Get the LoginBean from session attribute
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        LoginBean session = (LoginBean) req.getSession().getAttribute("bean1");
        String url = req.getRequestURI();

        // For the first application request there is no LoginBean in the session so user needs to log in
        // For other requests LoginBean is present but we need to check if user has logged in successfully
        if (session == null || !session.loggedIn) {
            if (url.indexOf("index2.xhtml") >= 0 || url.indexOf("logout.xhtml") >= 0 ) {
                String contextPath = req.getServletContext().getContextPath();
                resp.sendRedirect(contextPath + "/register.xhtml?faces-redirect=true");
            }
            else if ( url.contains("javax.faces.resources") ){
                chain.doFilter(request, response);
            }
            else {
                chain.doFilter(request, response);
            }

        } else {
            if (url.indexOf("index.xhtml") >= 0 || url.indexOf("register.xhtml") >= 0) {
                String contextPath = req.getServletContext().getContextPath();
                resp.sendRedirect(contextPath + "/index2.xhtml?faces-redirect=true");
            } else if (url.indexOf("logout.xhtml") >= 0) {
                req.getSession().removeAttribute("bean1");
                String contextPath = req.getServletContext().getContextPath();
                resp.sendRedirect(contextPath + "/register.xhtml");
            } else if ( url.contains("javax.faces.resources") ){
                chain.doFilter(request, response);
            } else {
                chain.doFilter(request, response);
            }
        }

    }

    @Override
    public void init(FilterConfig config) throws ServletException {
        // Nothing to do here!
    }

    @Override
    public void destroy() {
        // Nothing to do here!
    }
}
