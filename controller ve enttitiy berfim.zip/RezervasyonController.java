/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.RezervasyonDAO;
import Entitiy.Rezervasyon;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="rezervasyon")
@SessionScoped
public class RezervasyonController {
    private Rezervasyon r =null;
    private ArrayList<Rezervasyon> rlist =null;
    private  RezervasyonDAO rDAO=null;

    public Rezervasyon getR() {
        if(this.r==null)
            this.r =new Rezervasyon();
        return r;
    }

    public void setR(Rezervasyon r) {
        this.r = r;
    }

    public ArrayList<Rezervasyon> getlist() {
        if(this.rlist==null){
            this.rlist=new ArrayList();
            rlist=this.getrDAO().list();
                    }
        return this.rlist;
    }

    public void setlist(ArrayList<Rezervasyon> list) {
        this.rlist = list;
    }

    public RezervasyonDAO getrDAO() {
        if(this.rDAO==null)
            this.rDAO = new RezervasyonDAO();
        return rDAO;
    }

    public void setrDAO(RezervasyonDAO rDAO) {
        this.rDAO = rDAO;
    }
    public String delete(int id) {
        this.getrDAO().delete(id);
        this.rlist = this.getrDAO().list();
        return "/pages/adminstation/rezervasyon/list";
    }

    public Rezervasyon getRezervasyonById(int id) {
        return this.getrDAO().getRezervasyon(id);
    }
    
    public String update(int id){
        this.r=this.getRezervasyonById(id);
        return "/pages/adminstation/Rezervasyon/update";
    }

    public String updateRezervasyon(int id){
        this.getrDAO().update(this.r);
        this.rlist = this.getrDAO().list();
        return "/pages/adminstation/Rezervasyon/list";
    }
    
    public String createRezervasyon() {
        this.getrDAO().create(this.r);
        this.rlist = this.getrDAO().list();
        this.r=null;
        return "/pages/adminstation/Rezervasyon/list";
    }
    
    
    
}
