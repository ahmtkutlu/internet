/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;


import DAO.AdisyonDAO;
import Entitiy.Adisyon;
import java.util.ArrayList;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 *
 * @author BURCU
 */
@ManagedBean(name="adisyon")
@SessionScoped
public class AdisyonController {
    private Adisyon a =null;
    private ArrayList<Adisyon> alist =null;
    private  AdisyonDAO aDAO=null;

    public Adisyon getA() {
        if(this.a==null)
            this.a =new Adisyon();
        return a;
    }

    public void setA(Adisyon a) {
        this.a = a;
    }

    public ArrayList<Adisyon> getlist() {
        if(this.alist==null){
            this.alist=new ArrayList();
            alist=this.getaDAO().list();
                    }
        return this.alist;
    }

    public void setlist(ArrayList<Adisyon> list) {
        this.alist = list;
    }

    public AdisyonDAO getaDAO() {
        if(this.aDAO==null)
            this.aDAO = new AdisyonDAO();
        return aDAO;
    }

    public void setaDAO(AdisyonDAO aDAO) {
        this.aDAO = aDAO;
    }
    public String delete(int id) {
        this.getaDAO().delete(id);
        this.alist = this.getaDAO().list();
        return "/pages/adminstation/adisyon/list";
    }

    public Adisyon getAdisyonById(int id) {
        return this.getaDAO().getAdisyon(id);
    }
    
    public String update(int id){
        this.a=this.getAdisyonById(id);
        return "/pages/adminstation/Adisyon/update";
    }

    public String updateAdisyon(int id){
        this.getaDAO().update(this.a);
        this.alist = this.getaDAO().list();
        return "/pages/adminstation/Adisyon/list";
    }
    
    public String createAdisyon() {
        this.getaDAO().create(this.a);
        this.alist = this.getaDAO().list();
        this.a=null;
        return "/pages/adminstation/Adisyon/list";
    }
    
    
    
}
